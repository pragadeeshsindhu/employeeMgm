package com.example.crudDemoUsing.h2.repo;

import com.example.crudDemoUsing.h2.entity.employee;
import org.springframework.data.annotation.Id;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repos extends JpaRepository <employee, Integer> {
}
