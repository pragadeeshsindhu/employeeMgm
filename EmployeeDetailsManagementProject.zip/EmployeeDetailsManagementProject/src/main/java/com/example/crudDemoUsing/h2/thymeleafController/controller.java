package com.example.crudDemoUsing.h2.thymeleafController;

import com.example.crudDemoUsing.h2.entity.employee;
import com.example.crudDemoUsing.h2.repo.repos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class controller {

    @Autowired
    repos r;
    @RequestMapping("/")
    public String  list(Model themodel)
    {
        List<employee>ls=new ArrayList<>();
        ls=r.findAll();
        themodel.addAttribute("list",ls);
        return "displayDetails";
    }
    @RequestMapping("/addingForm")
    public String  addform(Model m)
    {
        employee emp=new employee();
        m.addAttribute("employee",emp);
       return "form";
    }
    @PostMapping("/saveModel")
    public String saveModel(@ModelAttribute("employee")employee e)
    {
        r.save(e);
        return "redirect:/";
    }
    @RequestMapping("/updatethis")
    public String  updatethis(@RequestParam("id")int id,Model m)
    {
        employee e=new employee();
        Optional<employee> result=r.findById(id);
        if(result.isPresent())e=result.get();
        m.addAttribute("employee",e);
        return "form";
    }
    @RequestMapping("/deletethis")
    public String  deletethis(@RequestParam("id")int id)
    {
       r.deleteById(id);
       return "redirect:/";
    }
}
