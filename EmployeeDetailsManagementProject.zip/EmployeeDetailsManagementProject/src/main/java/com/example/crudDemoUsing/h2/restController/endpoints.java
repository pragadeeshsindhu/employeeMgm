package com.example.crudDemoUsing.h2.restController;

import com.example.crudDemoUsing.h2.entity.employee;
import com.example.crudDemoUsing.h2.repo.repos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employees")
public class endpoints {
    @Autowired
    repos r;
    @PostConstruct
    public void PublishData()
    {
        employee e=employee.builder().name("praga").build(); r.save(e);
        employee e1=employee.builder().name("naveen").build(); r.save(e1);
        employee e2=employee.builder().name("nithesh").build(); r.save(e2);
        employee e3=employee.builder().name("thor").build(); r.save(e3);
    }
    @RequestMapping(value = "/post",method = RequestMethod.POST)
    public void add(@RequestBody employee e)
    {
        r.save(e);
    }
    @RequestMapping(value = "/put",method = RequestMethod.PUT)
    public void update(@RequestBody employee e)
    {
       r.save(e);
    }
    @RequestMapping(value = "/getall",method = RequestMethod.GET)
    public List<employee> display()
    {
        return r.findAll();
    }
    @RequestMapping(value = "/{id}",method = RequestMethod.GET)
    public employee getid(@PathVariable("id")int id)
    {
        Optional<employee>result=r.findById(id);
        if(result.isPresent())return result.get();
        else throw new RuntimeException("no data found");
    }
    @RequestMapping(value = "/delete/{id}",method = RequestMethod.DELETE)
    public void delete(@PathVariable("id")int id)
    {
         r.deleteById(id);
    }
}
